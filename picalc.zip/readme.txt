В Ubuntu введите:

sudo apt-get install idle3
pip install pyqt5

Запустите picalc.pyw через IDLE3.