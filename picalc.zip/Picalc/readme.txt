WINDOWS

Установите Python по ссылке: https://www.python.org/ftp/python/3.5.2/python-3.5.2.exe

Нажмите Win+R и в командной строке введите:

pip install pyqt5

Запустите picalc.pyw.

Можно создать ярлык на рабочий стол с помощью прилагаемой иконки.

UBUNTU

Введите:

sudo apt-get install python3-pyqt5

sudo apt-get install idle3

Запустите picalc.pyw через IDLE3 (File – Open – F5).