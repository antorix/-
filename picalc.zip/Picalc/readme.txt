WINDOWS

Установите Python по ссылке: https://www.python.org/ftp/python/3.5.2/python-3.5.2.exe

Запустите install.bat

Запустите picalc.pyw

UBUNTU

Введите:

sudo apt-get install python3-pyqt5

sudo apt-get install idle3

Запустите picalc.pyw через IDLE3 (File – Open – F5)

В архив входят иконки для создания ярлыка (ico, png)